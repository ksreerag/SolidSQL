cls
# "              ************************************************************"
# "              ************************************************************"
# "              ** Script for SQL patching remotely with Multiple servers **"
# "              ** Tower : Database Architecture & Delivery               **"
# "              ************************************************************"
# "              ************************************************************"
Function GetFQHostName () {
    $objIPProperties = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()
    if ($objIPProperties.DomainName) {
        set-variable -name "fqhostname" ("{0}.{1}" -f $objIPProperties.HostName, $objIPProperties.DomainName) -scope script
    }
    else {
        set-variable -name "fqhostname" $objIPProperties.HostName -scope script
    }
}

Function Find-Listener () {
    Param (
        [Parameter(Mandatory=$true, Position=0)] [Int]  $FindPort,
        [Parameter(Mandatory=$true, Position=1)] [String] $FindProtocol
    )
    try {
        set-variable -name listener (get-WSManInstance winrm/config/listener -SelectorSet @{Address="*";Transport="$localProtocol"} ) -scope script 
    }
    catch [system.exception] {set-variable -name listener "" -scope script}
    if ($listener) {
        $Rtn = $true
    }
    else {
        $Rtn = $false
    }
    Return $Rtn
}

Function Test-WinRM () {
    Param (
        [array] $WinRM_Ports =@(5985, 5986)
    )
    write-Host "Test WinRM Function calling"
    [string]$localProtocol="HTTP"
    ForEach ($localPort in $WinRM_Ports) {
        if (($localPort)) {
            switch ($localPort) {
            "5985"  {$localProtocol = "HTTP"}
            "5986" { $localProtocol = "HTTPS"}
            }
        }
        $ListenerOK = Find-Listener $localPort $localProtocol
        write-Host "Listener $localProtocol on $localPort = $ListenerOK"
        If ($ListenerOK) {
            write-Host "WinRM Listener is able to reach port $localPort on $localProtocol"
            if ($locaProtocol = "HTTPS") {
                GetFQHostName
                $certs =  (Get-ChildItem Cert:\LocalMachine\My | Where-Object {$_.Subject -eq "CN=$fqhostname"})
                if ($certs -eq "") {
                    write-Host "Cert is not FQDN valid. Please create New cert and attach it to Winrm HTTPS listener"
                }
                else{
                    $localthumbprint = (Get-WSManInstance -ResourceURI winrm/config/listener -SelectorSet @{Address="*";Transport="https"}).CertificateThumbprint
                    foreach ($cert in $certs) {
                        if (!($cert).CertificateThumbprint -eq $localthumbprint) {
                            continue  
                        }
                        else {
                            $certToValidate = $cert
                            if (($certToValidate).NotAfter -le (Get-Date).AddDays(30)) {
                                write-Host "Certificate is FQDN valid and Not Expired."
                            }  
                            else {
                                write-Host "Certificate in store is FQDN valid, but IS expired. Please Attach a new Self Signed Certificate to the Winrm HTTPS listener."
                            }
                        }
                    }
                }
            }
        } 
        Else {
            write-Host "WinRM Listener is unable to reach port  $localPort on $localProtocol - enable WinRM is needed"
        }
        #   echo "Find-Listener Function returned"
    }
    write-Host -SECTION "SOFTWARE" -log_message "Test WinRM Function Finished"
}
    
Test-WinRM