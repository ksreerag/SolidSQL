cls
# "              ************************************************************"
# "              ************************************************************"
# "              ** Script for SQL patching remotely with Multiple servers **"
# "              ** Tower : Database Architecture & Delivery               **"
# "              ************************************************************"
# "              ************************************************************"
Param ( [string]$Port="", [ValidateSet("HTTPS")] [string]$Protocol="HTTPS")
if (!($Port)) {
  switch ($Protocol) {
    "HTTP"  {$Port = "5985"}
    "HTTPS" {$Port = "5986"}
    }
  }

# Create log directory if it does not exist
$path = "c:\platformdxc\log"
If(!(test-path $path))
{
      New-Item -ItemType Directory -Force -Path $path
}

Function SelfCert ($validityyears=10) {
  $objIPProperties = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()
  if ($objIPProperties.DomainName)
  {$fqhostname = "{0}.{1}" -f $objIPProperties.HostName, $objIPProperties.DomainName}
  else
  {$fqhostname = $objIPProperties.HostName}

  $name = new-object -com "X509Enrollment.CX500DistinguishedName.1"
  $name.Encode("CN=$fqhostname", 0)

  $key = new-object -com "X509Enrollment.CX509PrivateKey.1"
  $key.ProviderName = "Microsoft RSA SChannel Cryptographic Provider"
  $key.KeySpec = 1
  $key.Length = 2048
  $key.SecurityDescriptor = "D:PAI(A;;0xd01f01ff;;;SY)(A;;0xd01f01ff;;;BA)(A;;0x80120089;;;NS)"
  $key.MachineContext = 1
  $key.Create()

  $serverauthoid = new-object -com "X509Enrollment.CObjectId.1"
  $serverauthoid.InitializeFromValue("1.3.6.1.5.5.7.3.1")
  $ekuoids = new-object -com "X509Enrollment.CObjectIds.1"
  $ekuoids.add($serverauthoid)
  $ekuext = new-object -com "X509Enrollment.CX509ExtensionEnhancedKeyUsage.1"
  $ekuext.InitializeEncode($ekuoids)

  $cert = new-object -com "X509Enrollment.CX509CertificateRequestCertificate.1"
  $cert.InitializeFromPrivateKey(2, $key, "")
  $cert.Subject = $name
  $cert.Issuer = $cert.Subject
  $cert.NotBefore = [DateTime]::UtcNow
  $cert.NotAfter = $cert.NotBefore.AddYears($validityyears)
  $cert.X509Extensions.Add($ekuext)
  $cert.Encode()

  $enrollment = new-object -com "X509Enrollment.CX509Enrollment.1"
  $enrollment.InitializeFromRequest($cert)
  $certdata = $enrollment.CreateRequest(0)
  $enrollment.InstallResponse(2, $certdata, 0, "")
  if ($?) {LogMessage "Created cert"} else {LogMessage "Could not create cert";}
  start-sleep 5
  # Get the thumbprints of the SSL Server Auth certificates that match the hostname
  $myCert=dir cert:\localmachine\my | ? {$_.Subject -eq "CN=$fqhostname"}| ? {$_.Extensions | % { $_.EnhancedKeyUsages | ? {$_.FriendlyName -eq "Server Authentication"}}} | sort-object -property notafter|select-object -last 1
  $myCert.FriendlyName="AgilityWinRM"
  set-variable -name thumbprint $myCert.Thumbprint -scope script
  <# Trust the cert
  $store = New-Object System.Security.Cryptography.X509Certificates.X509Store "Root","LocalMachine"
  $store.Open("ReadWrite")
  $store.Add($myCert)
  $store.Close()
  #>
}
function Is-PendingReboot {
  try  {
    $Computer = $env:computername
    $PendFileRename,$Pending = $false,$false
    $CBSRebootPend = $null
    $myOS = Get-WmiObject -Class Win32_OperatingSystem -Property BuildNumber, CSName -ComputerName $Computer
    $RegCon = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey([Microsoft.Win32.RegistryHive]"LocalMachine",$Computer)
    If ($myOS.BuildNumber -ge 6001) {
        $RegSubKeysCBS = $RegCon.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\").GetSubKeyNames()
        $CBSRebootPend = $RegSubKeysCBS -contains "RebootPending"
    }
    $RegWUAU = $RegCon.OpenSubKey("SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\")
    $RegWUAURebootReq = $RegWUAU.GetSubKeyNames()
    $WUAURebootReq = $RegWUAURebootReq -contains "RebootRequired"
    $RegSubKeySM = $RegCon.OpenSubKey("SYSTEM\CurrentControlSet\Control\Session Manager\")
    $RegValuePFRO = $RegSubKeySM.GetValue("PendingFileRenameOperations",$null)
    $RegCon.Close()
    #if ($RegValuePFRO) {
    #    $PendFileRename = $true
    #}
    if ($CBSRebootPend -or $WUAURebootReq -or $PendFileRename)  {
       $Pending = $true
    }
    $SelectSplat = @{
        Property=('Computer','CBServicing','WindowsUpdate','PendFileRename','PendFileRenVal','RebootPending')
    }
#   New-Object -TypeName PSObject -Property @{
#       Computer=$Computer
#       CBServicing=$CBSRebootPend
#       WindowsUpdate=$WUAURebootReq
#       PendFileRename=$PendFileRename
#       PendFileRenVal=$RegValuePFRO
#       RebootPending=$Pending
#    } | Select-Object @SelectSplat
    return $Pending
  }
  catch  {
    Write-Host "$Computer`: $_"
  }
}
Function LogMessage () {
  Param ( [string]$message, [switch]$earlyExit)
  $logfile = "$($env:SYSTEMDRIVE)\platformdxc\log\platformdxc.log"
  if ($message) {$message = "$(get-date)    " + $message}
  out-file $logfile -inputObject $message -encoding "ASCII" -Append
  if ($earlyExit) {LogMessage "FATAL ERROR: exiting";exit 1}
}

Function GetFQHostName () {
  $objIPProperties = [System.Net.NetworkInformation.IPGlobalProperties]::GetIPGlobalProperties()
  if ($objIPProperties.DomainName)
    {set-variable -name "fqhostname" ("{0}.{1}" -f $objIPProperties.HostName, $objIPProperties.DomainName) -scope script}
  else
    {set-variable -name "fqhostname" $objIPProperties.HostName -scope script}
}

Function WaitUntilCustomizationFinished () {
  $custtools='guestcustutil`\bogusguestcusttool'
  while (((get-itemproperty "hklm:/SYSTEM/Setup").SystemSetupInProgress -ne 0) -or (Is-PendingReboot) -or ((get-process | %{$_.Processname}|select-string -pattern $custtools).count -gt 0))
  {
    LogMessage "Sysprep not yet complete"
    LogMessage "Stopping WinRM until sysprep is done"
    stop-service WinRM
    if ($?) {LogMessage "Stopped WinRM"} else {LogMessage "Could not stop WinRM"}

    set-service WinRM -startuptype "manual"
    start-sleep 30
  }
}

Function EnableListener () {
  if ($listener) {set-variable -name listener (set-wsmaninstance winrm/config/listener -SelectorSet @{Address="*";Transport="$protocol"} -ValueSet @{Port="$Port";Enabled="true"}) -scope script }
  if ($listener.Enabled -eq "true") {
    $ips = $listener.ListeningOn -join ","
    LogMessage "$protocol listener on port $port is enabled and listening on addresses $ips"
  }
  else {LogMessage "$protocol listener on port $port not enabled"}
}

Function FindListener () {
  try {set-variable -name listener (get-wsmaninstance winrm/config/listener -SelectorSet @{Address="*";Transport="$protocol"} ) -scope script }
  catch [system.exception] {set-variable -name listener "" -scope script}
  if ($listener) {LogMessage "Found $protocol listener on port $port"}
  else {LogMessage "$protocol listener on port $port not found"}
}

Function CreateListener () {
  switch ($Protocol) {
    "HTTP" {
      set-variable -name listener (new-wsmaninstance winrm/config/listener -SelectorSet @{Address="*";Transport="$protocol"} -valueset @{Port="$Port"}) -scope script
      if ($?) {LogMessage "Created $protocol protocol listener on port $port"} else {LogMessage "Could not create $protocol protocol listener on port $port" -earlyexit}
    }
    "HTTPS" {
      if ($thumbprint) {
        set-variable -name listener (new-wsmaninstance winrm/config/listener -SelectorSet @{Address="*";Transport="$protocol"} -valueset @{Port="$Port";Hostname="$fqhostname";CertificateThumbprint="$Thumbprint"}) -scope script
        if ($?) {LogMessage "Created $protocol protocol listener on port $port with hostname $fqhostname and cert thumbprint $thumbprint"}
        else {LogMessage "Could not create  $protocol protocol listener on port $port with hostname $fqhostname and cert thumbprint $thumbprint" -earlyexit}
      }

    }
  }
}

Function AssertCert () {
  GetFQHostName
  #Find suitable Server Authentication cert or create self-signed one
  $certs=dir cert:\localmachine\my |? {$_.Subject -eq "CN=$fqhostname"}| ? {$_.Extensions | % { $_.EnhancedKeyUsages | ? {$_.FriendlyName -eq "Server Authentication"}}}
  set-variable -name thumbprint ($certs|?{$_.verify()}|sort-object -property notafter | select-object -last 1 -expandproperty thumbprint) -scope script
  if ($thumbprint) {LogMessage "Found verified server authentication cert with thumbprint $thumbprint"}
  else {
    set-variable -name thumbprint ($certs|sort-object -property notafter | select-object -last 1 -expandproperty thumbprint) -scope script
    if ($thumbprint) {LogMessage "Found unverified server authentication cert with thumbprint $thumbprint"}
    else {
      SelfCert
      if ($thumbprint) {LogMessage "Built self-signed cert with thumbprint $thumbprint"}
      else {LogMessage "Unable to create self-signed cert with hostname $fqhostname" -earlyexit}
    }
  }
}

Function AssignCertToListener () {
  if ($listener -and $thumbprint) {
    set-variable -name listener (set-wsmaninstance winrm/config/listener -SelectorSet @{Address="*";Transport="$protocol"} -ValueSet @{Port="$Port";Hostname="$fqhostname";CertificateThumbprint="$thumbprint";Enabled="true"}) -scope script
    if ($?) {
      $ips = $listener.ListeningOn -join ","
      LogMessage "$protocol listener on port $port is listening on addresses $ips"
    }
    else {LogMessage "Unable to set listener to use cert with $thumbprint" -earlyexit}
  }
}

Function AddFirewallRule () {
  # Add a firewall rule to the local computer to allow WinRM 
  $osver=[environment]::osversion.version
  if ($osver.major -eq 6 -and $osver.minor -eq 1) {
    # For windows 2008 R2 use netsh
    netsh advfirewall firewall show rule name="Allow HTTP WinRM 5985"
    If (-not $?) {
      netsh advfirewall firewall add rule name="Allow HTTP WinRM 5985" dir=in action=allow protocol=TCP localport=5985
      if ($?) {LogMessage "Added Firewall rule for port 5985" } else {LogMessage "Error adding Firewall rule for port 5985"}
    }
    else {LogMessage "Firewall rule for port 5985 already exists"}
    netsh advfirewall firewall show rule name="Allow HTTPS WinRM 5986"
    If (-not $?) {
      netsh advfirewall firewall add rule name="Allow HTTPS WinRM 5986" dir=in action=allow protocol=TCP localport=5986
      if ($?) {LogMessage "Added Firewall rule for port 5986" } else {LogMessage "Error adding Firewall rule for port 5986"}
    }
    else {LogMessage "Firewall rule for port 5986 already exists"}
  } else {
    # For anything other than Windows 2008 R2 use New-NetFirewallRule
    $rule = Get-NetFirewallRule -DisplayName "Allow HTTP WinRM 5985" -ErrorAction SilentlyContinue
    If (-not $rule) {
    New-NetFirewallRule -Name "Allow HTTP WinRM 5985" -DisplayName "Allow HTTP WinRM 5985" -Enabled 1 -Direction Inbound -Action Allow -LocalPort 5985 -Protocol TCP
    if ($?) {LogMessage "Added Firewall rule for port 5985" } else {LogMessage "Error adding Firewall rule for port 5985"}
    }
    else {LogMessage "Firewall rule for port 5985 already exists"}
    $rule = Get-NetFirewallRule -DisplayName "Allow HTTPS WinRM 5986" -ErrorAction SilentlyContinue
    If (-not $rule) {
    New-NetFirewallRule -Name "Allow HTTPS WinRM 5986" -DisplayName "Allow HTTPS WinRM 5986" -Enabled 1 -Direction Inbound -Action Allow -LocalPort 5986 -Protocol TCP
    if ($?) {LogMessage "Added Firewall rule for port 5986" } else {LogMessage "Error adding Firewall rule for port 5986"}
    }
    else {LogMessage "Firewall rule for port 5986 already exists"}
  
  }
}

Function EnableTLS12 () {
    param(
        [ValidateSet("Server", "Client")]
        [String]$Component = "Server"
    )
    LogMessage "Ensuring that TLS v1.2 is enabled for $Component"
    $protocols_path = 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols'
    if (-not (Test-Path "$protocols_path\TLS 1.2\$Component")) {
    LogMessage "Adding Registry Path for TLS 1.2 $Component"
    New-Item -Path "$protocols_path\TLS 1.2\$Component" -Force
    }

    if ((Get-ItemProperty -Path "$protocols_path\TLS 1.2\$Component" | Select-Object -ExpandProperty Enabled -ErrorAction SilentlyContinue) -ne "1") {
    New-ItemProperty -Path "$protocols_path\TLS 1.2\$Component" -Name Enabled -Value 1 -Type DWORD -Force
    if ($?) {LogMessage "Enabling TLS v1.2 for $Component - Set Enabled=1 - Reboot Required" } else { Logmessage "Error enabling TLS v1.2 for $Component"}
    } else {
    LogMessage "TLS v1.2 for $Component already has Enabled=1"
    }

    if ((Get-ItemProperty -Path "$protocols_path\TLS 1.2\$Component" | Select-Object -ExpandProperty DisabledByDefault -ErrorAction SilentlyContinue) -ne "0") {
    New-ItemProperty -Path "$protocols_path\TLS 1.2\$Component" -Name DisabledByDefault -Value 0 -Type DWORD -Force
    if ($?) {LogMessage "Enabling TLS v1.2 for $Component - Set DisabledByDefault=0 - Reboot Required" } else { Logmessage "Error enabling TLS v1.2 for $Component"}
    } else {
    LogMessage "TLS v1.2 for $Component already has DisabledByDefault=0"
    }
}

# Start here

# LogMessage "Waiting 90 seconds to check system status"
# start-sleep 90

# Check OS version and exit for unsupported versions
$osver=[environment]::osversion.version
if (($osver.major -eq 6 -and $osver.minor -eq 0) -or ($osver.major -lt 6)) {
  LogMessage "Unsupported OS Version. Only Windows 2008 R2 or later is supported";return
}

# Enable TLS v1.2 (for windows 2008 R2 only)
if ($osver.major -eq 6 -and $osver.minor -eq 1) {
  EnableTLS12 -Component Server
  # Client component is recommended but not required. The following line can be commented out if necessary.
  EnableTLS12 -Component Client
}

WaitUntilCustomizationFinished

start-service WinRM
if ($?) {LogMessage "Started WinRM"}
else {Logmessage "Could not start WinRM"}

FindListener

if ($listener) {
  EnableListener
  if ($protocol -eq "HTTPS") {
    AssertCert
    AssignCertToListener
  }
}
else {
  if ($protocol -eq "HTTPS") {AssertCert}
  CreateListener
  EnableListener
}

Set-ItemProperty -Path "Registry::HKLM\System\CurrentControlSet\Services\WinRM" -Name "DelayedAutostart" -Value 1 -Type DWORD
set-service WinRM -startuptype "Automatic"
if ($?) {LogMessage "WinRM is set to autostart"} else {LogMessage "Could not set WinRM to autostart"}

# Add Firewall Rule
AddFirewallRule

# Enable CredSSP

Enable-WSManCredSSP -Role Server -Force
if ($?) {LogMessage "CredSSP Enabled"} else {LogMessage "Error Enabling CredSSP"}

Write-Verbose -Message "Script complete"
LogMessage ""
