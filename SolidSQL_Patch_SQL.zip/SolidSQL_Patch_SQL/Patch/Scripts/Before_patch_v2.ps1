﻿cls
Write-Host "              ************************************************************"
Write-Host "              ************************************************************"
Write-Host "              ** Script for SQL patching remotely with Multiple servers **"
Write-Host "              ** Tower : Database Architecture & Delivery               **" 
Write-Host "              ************************************************************"
Write-Host "              ************************************************************"
#$Parent_Path = $args[0]
Start-Sleep -Seconds 5
function Test-Admin {
$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
if ((Test-Admin) -eq $false) {
if ($elevated)
{
Write-Host "tried to elevate, did not work, aborting"
} else {
Start-Process powershell.exe -Verb RunAs -ArgumentList ('-noprofile -noexit -file "{0}" -elevated' -f ($myinvocation.MyCommand.Definition))
}
exit
}
$Parent_Path = $args[0]
Split-Path -Path $Parent_Path -Qualifier
cd $Parent_Path
$server_name = $env:computername
$outfile2 = "$Parent_Path\logs\Patch_$(Get-Date -UFormat "%m-%Y").log"
$arg_log = "$Parent_Path\logs"
$arg_input = gc $arg_log\input.txt
$arg_input = $arg_input.Split(",")

Write-Output "$(get-date) : Installation started......." |Out-File $outfile2 -Append
#patch Install
$param1 = $arg_input[0] # patchexe
$param2 = $arg_input[1] # Instance
$param3 = $arg_input[2] # Allow Reboot
$param4 = $arg_input[3] # SQL_Binary_Path
$param9 = $arg_input[7] # Bootstrap Log path
$param6 = $arg_input[4] # Master script execution path
$param7 = $arg_input[5] # Username
$param8 = $arg_input[6] # Password

#Decode
$MYTEXT = "$param8"
$DECODED = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($MYTEXT))
net use y: $param6 /user:$param7 $DECODED

$param2 = $param2.Split(";")
if ($param2.ToLower() -eq "all"){
$arg_instance = ($server_name | Foreach-Object {Get-ChildItem -Path "SQLSERVER:\SQL\$_"}).InstanceName
$job = Start-Job -ScriptBlock {cmd /c $using:param1 /q /IAcceptSQLServerLicenseTerms /Action=Patch /AllInstances}
$job
Wait-Job $job
} else {
foreach ($Instance in $param2){
$job = Start-Job -ScriptBlock {cmd /c $using:param1 /q /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceName=$using:Instance}
$job
Wait-Job $job
$arg_instance = $Instance
} # end of foreach loop
} # end of instance($param4) check

#validation of patch installation
Import-Module sqlserver
foreach ($instance in $arg_instance){
if ($arg_instance -eq "MSSQLSERVER"){ 
    $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name" -Query "SELECT @@VERSION"
    }
Else {
    $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name\$arg_instance" -Query "SELECT @@VERSION"
    }
$arg_details.Column1 -match 'KB\d*'
$New_KBnumber = $Matches[0]
#Write-Output "$arg_KB" | Out-File $arg_log\KBnumber1.txt
}
#$New_KBnumber = gc $arg_log\KBnumber1.txt
$arg_summary = gc "$param9\summary.txt"
$arg_summary -replace (",","") | Out-File $arg_log\summary.txt
$arg_summary = gc "$arg_log\summary.txt"
$KBnumber = gc $arg_log\KBnumber.txt

if($KBnumber -eq $New_KBnumber){
$param1 -match '(KB\d+)'
$patchKB = $Matches[0]
if ($patchKB -eq $New_KBnumber) {
Write-Output "$(get-date) : This patch is already installed" |Out-File $outfile2 -Append
Write-Output "$env:computername,Successfull,Patch is already installed and server is rebooted,NA,'$arg_summary'" | out-file y:\report\summaryreport.csv -Append
del $arg_log\*.txt
exit
} else {
$arg_patchstatus = "False"
Write-Output "$env:computername,Failed,Patch install failed and server is rebooted,NA,'$arg_summary'" | out-file y:\report\summaryreport.csv -Append
del $arg_log\*.txt
exit
}
#Report in summary report
}else{
Write-Output "$(get-date) : Patches are successfully installed" | Out-File $outfile2 -Append
#del $arg_log\*.txt
}
Start-Sleep -Seconds 10
#System reboot
if($param3.ToLower() -eq "y"){
Write-Output "$(get-date) : reboot selected, hence server will be rebooted" | Out-File $outfile2 -Append
cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "LocaleSettings" /t REG_EXPAND_SZ /d "powershell.exe $Parent_Path\After_patch_v2.ps1 $Parent_Path" /f
cmd /c shutdown -r -t 0
}else{
Write-Output "$(get-date) : reboot not selected, hence server was not rebooted,NA" | Out-File $outfile2 -Append
}
net use y: /delete