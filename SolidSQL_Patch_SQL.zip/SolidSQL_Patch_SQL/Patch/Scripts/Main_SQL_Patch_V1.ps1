﻿ cls
 Write-Host "              ************************************************************" 
 Write-Host "              ************************************************************"
 Write-Host "              ** Script for SQL patching remotely with Multiple servers **"
 Write-Host "              ** Tower : Database Architecture & Delivery               **"
 Write-Host "              ************************************************************"
 Write-Host "              ************************************************************"

#$Parent_Path = $args[0]

    function Test-Admin 
            {
                        $currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
                        $currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
            }

    if ((Test-Admin) -eq $false) 
            {
                    if ($elevated)
                            {
                                    Write-Host "tried to elevate, did not work, aborting"
                             } 
                             else 
                             {
                                     Start-Process powershell.exe -Verb RunAs -ArgumentList ('-noprofile -noexit -file "{0}" -elevated' -f ($myinvocation.MyCommand.Definition))
                            }
                    exit
            }

     $Parent_Path = $args[0]

#$Parent_Path = "C:\SQL_Patch_Auto" #any changes in path, update here

    $arg_input = gc $Parent_Path\Master_input.log
    $arg_input = $arg_input.Split(",")

#To define parameters
    $param1=$arg_input[0]   #Source of master script location
    $param2=$arg_input[1]  #allow reboot
    $param3=$arg_input[2]  #patch exe
    $param4=$arg_input[9] #bootstraplog path
    $param5=$arg_input[3] #sql instances
    $param6=$arg_input[4] #bakupdir path
    $param7=$arg_input[5] #Remote_patchpath
    $param8=$arg_input[6] # SQL_Binary_Path
    $param9=$arg_input[7] # UserName
    $param10=$arg_input[8] # Password
    $param11=$arg_input[10] # SSMS_Patch
    $param12=$arg_input[11] # SSMS_Patch_Name
    $param13=$arg_input[12] # SSRS_Patch
    $param14=$arg_input[13] # SSRS_Patch_Name

#$arg_patchfile = Split-Path "$param3" -leaf -ErrorAction SilentlyContinue

    $arg_patchexe = "$param7\$param3"

#Decode
    $MYTEXT = "$param10"
    $DECODED = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($MYTEXT))

    $server_name = $env:computername
    net use y: $param1 /user:$param9 $DECODED

#Creating folder structure
#creating archive folder to move processed files
    $arg_archive= Test-Path "$Parent_Path\archive"
    
    if($arg_archive)
            {} 
    else
            {
                    New-Item -Path "$Parent_Path" -Name "archive" -ItemType "directory" -Force
            }

    $arg_log = "$Parent_Path\logs"
    $arg_log1= Test-Path $arg_log

    if($arg_log1)
            {
                    $arg_file_exist=Test-Path "$Parent_Path\logs\*.log" -PathType Leaf
                    if($arg_file_exist)
                            {
                                    Move-Item -Path "$Parent_Path\logs\*.*" -Destination "$Parent_Path\archive" -Force
                            }
              } 
    else
              {
                    New-Item -Path "$Parent_Path" -Name "logs" -ItemType "directory" -Force
               }


# creating Record folder to record success and failure of step
    $arg_Reports = Test-Path "$Parent_Path\Reports"
    
    if($arg_Reports)
            {
                    $arg_file_exist=Test-Path "$Parent_Path\Reports\*.txt" -PathType Leaf
                    
                    if($arg_file_exist)
                            {
                                        Move-Item -Path "$Parent_Path\Reports\*.*" -Destination "$Parent_Path\archive" -Force
                            }
            }
    else 
            {
                    md "$Parent_Path\Reports"
            }


#Log File

    $outfile2 = "$Parent_Path\logs\Patch_$(Get-Date -UFormat "%m-%Y").log"

#Write-Output "Test_verified" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for installation binary files is $param8" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for allow reboot is $param2" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for patch path is $param3" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for bootstraplog path is $param4" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for sql instances is $param5" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for bakupdir path is $param6" | Out-File $outfile2 -Append
    Write-Output "$(get-date) : Input parameter for Remote_patchpath is $param7" | Out-File $outfile2 -Append

#To get 64bit
    Import-Module sqlserver  
    
    if ($param5.ToLower() -eq "all")
            {
                    $arg_instance = ($server_name | Foreach-Object {Get-ChildItem -Path "SQLSERVER:\SQL\$_"}).InstanceName
            }
    else 
            {
                    $arg_instance = $param5.Split(";")
            }  

    foreach ($instance in $arg_instance) 
                  { #Foreach instance
                                            if ($arg_instance -eq "MSSQLSERVER")
                                                    { 
                                                                $arg_arch= (Invoke-Sqlcmd -ServerInstance "$server_name" -Query "SELECT RIGHT(SUBSTRING(@@VERSION, CHARINDEX('<', @@VERSION), 4), 2)").column1
                                                    }
                                            Else 
                                                    {
                                                                $arg_arch= (Invoke-Sqlcmd -ServerInstance "$server_name\$instance" -Query "SELECT RIGHT(SUBSTRING(@@VERSION, CHARINDEX('<', @@VERSION), 4), 2)").column1
                                                    }

                                            Write-Output "$(get-date) : Architecture is $arg_arch bit" | Out-File $outfile2 -Append

                                            if ($arg_instance -eq "MSSQLSERVER")
                                                    { 
                                                                $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name" -Query "SELECT @@VERSION"
                                                    }
                                            Else 
                                                    {
                                                                $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name\$instance" -Query "SELECT @@VERSION"
                                                    }


#parsing sql and kb details using regx

                                            $arg_details.Column1 -match 'KB\d*'
                                            $arg_KB = $Matches[0]
                                            Write-Output "$(get-date) : Sql version is - $($arg_details.column1)" | Out-File $outfile2 -Append
                                            Write-Output "$arg_KB" | Out-File $arg_log\KBnumber.txt 

#DB backup with all user and system DB's

#Validate Backup Folder (Remote Server)
                                            $arg_log2= Test-Path $param6

                                            if($arg_log2)
                                                    {} 
                                            else
                                                    {
                                                            New-Item -Path "$param6" -ItemType "directory" -Force
                                                    }

                                            if ($arg_instance -eq "MSSQLSERVER")
                                                    { 
                                                            $arg_dbname = (Get-SqlInstance -ServerInstance "$server_name" | Get-SqlDatabase | Where { $_.Name -ne 'tempdb' }).Name
                                                    }
                                            Else 
                                                    {
                                                            $arg_dbname = (Get-SqlInstance -ServerInstance "$server_name\$instance" | Get-SqlDatabase | Where { $_.Name -ne 'tempdb' }).Name
                                                    }

                                            if ($arg_dbname)
                                                    {
                                                        foreach ($dbname in $arg_dbname)
                                                                {
                                                                    if ($arg_instance -eq "MSSQLSERVER")
                                                                            { 
                                                                                    Backup-SqlDatabase -ServerInstance "$server_name" -Database "$dbname" -BackupFile $param6\$dbname.bak
                                                                            }
                                                                    Else 
                                                                            {
                                                                                    Backup-SqlDatabase -ServerInstance "$server_name\$instance" -Database "$dbname" -BackupFile $param6\$dbname.bak
                                                                            }

                                                                    Write-Output "$(get-date) : Backup has been taken for DB - $dbname" | Out-File $outfile2 -Append
                                                                } # end of DB foreach
                                                    } 
                                            else 
                                                    {
                                                            Write-Output "$(get-date) : No DB found for backup" | Out-File $outfile2 -Append
                                                    }

# Collecting Maintenance Job details
                                            if ($arg_instance -eq "MSSQLSERVER")
                                                    { 
                                                            $arg_maintenance = Invoke-Sqlcmd -ServerInstance "$server_name" -Query "SELECT ja.job_id, j.name AS job_name, ja.start_execution_date, ISNULL(last_executed_step_id,0)+1 AS current_executed_step_id, Js.step_name FROM msdb.dbo.sysjobactivity ja LEFT JOIN msdb.dbo.sysjobhistory jh ON ja.job_history_id = jh.instance_id JOIN msdb.dbo.sysjobs j ON ja.job_id = j.job_id JOIN msdb.dbo.sysjobsteps js ON ja.job_id = js.job_id AND ISNULL(ja.last_executed_step_id,0)+1 = js.step_id WHERE ja.session_id = (SELECT TOP 1 session_id FROM msdb.dbo.syssessions ORDER BY agent_start_date DESC) AND start_execution_date is not null AND stop_execution_date is null;"
                                                    }
                                            Else 
                                                    {
                                                            $arg_maintenance = Invoke-Sqlcmd -ServerInstance "$server_name\$instance" -Query "SELECT ja.job_id, j.name AS job_name, ja.start_execution_date, ISNULL(last_executed_step_id,0)+1 AS current_executed_step_id, Js.step_name FROM msdb.dbo.sysjobactivity ja LEFT JOIN msdb.dbo.sysjobhistory jh ON ja.job_history_id = jh.instance_id JOIN msdb.dbo.sysjobs j ON ja.job_id = j.job_id JOIN msdb.dbo.sysjobsteps js ON ja.job_id = js.job_id AND ISNULL(ja.last_executed_step_id,0)+1 = js.step_id WHERE ja.session_id = (SELECT TOP 1 session_id FROM msdb.dbo.syssessions ORDER BY agent_start_date DESC) AND start_execution_date is not null AND stop_execution_date is null;"
                                                    }

                                            if ($arg_maintenance)
                                                    {
                                                            Write-Output "$(get-date) : Maintenance Jobs details - $arg_maintenance" | Out-File $outfile2 -Append
                                                    } 
                                            else 
                                                    {
                                                            Write-Output "$(get-date) : No maintenance jobs found" | Out-File $outfile2 -Append
                                                    }
                  } # end of instance foreach
    
        Remove-Module -Name Sqlserver

#Calling vbscript
    cscript $Parent_Path\FindSQLInstalls.vbs $arg_log\output.txt

#Check and fix MSI , MSP files
 
    $input = "$param8"   #source files folder
    $text = gc $arg_log\output.txt     
    $text | Select-String -Pattern 'Action needed, recreate or re-establish path.*' -Context 0,10 | out-file $arg_log\parsed.txt
    $Val_file = [String]::IsNullOrWhiteSpace((gc C:\SQL_Patch_Auto\logs\parsed.txt))

    if($Val_file)
            {
                    Write-Output "$(get-date) : No MSI/MSP fix found" | Out-File $outfile2 -Append
            } 
    else 
            { 
    $text1 = gc $arg_log\parsed.txt #-Raw
    $text1 | Select-String -Pattern '"\w+.*' -Context 0,1 | out-file $arg_log\parsed1.txt
    $hash = @{} 
    (gc $arg_log\parsed1.txt) | ? {$_.trim() -ne "" } | set-content $arg_log\parsed1.txt
    gc $arg_log\parsed1.txt | %{if($hash.$_ -eq $null) { $_ }; $hash.$_ = 1} | out-file $arg_log\parsed2.txt
    Set-Content -Path "$arg_log\parsed3.txt" -Value (get-content -Path "$arg_log\parsed2.txt" | Select-String -Pattern '> ' -NotMatch)

    Try 
            {
                    $text3 = (gc $arg_log\parsed3.txt -Raw -ErrorAction Continue).Trim()
                    $text3.Replace("`" `r`n"," ") | out-file $arg_log\parsed4.txt
            }
    Catch
            {
                    Write-Output "$(get-date) : File is empty" | Out-File $outfile2 -Append
                    $text3 = (gc $arg_log\parsed2.txt -Raw -ErrorAction Continue).Trim()
                    $text3.Replace(">        Copy ","") | out-file $arg_log\parsed4.txt
            }

    $text2 = (gc $arg_log\parsed4.txt).Trim()

    foreach ($source in $text2) 
            {
                            $source = $source.Replace("`"","")
                            $source1 = $source -split '   '
                    
                            if ($source1.Count -eq "1")
                                    {
                                            $source = $source -split ' '
                                    } 
                            else 
                                    {
                                            $source = $source -split '   '
                                    }

                            $source1 = $source[0]
                            $dest = $source[1]
                            $file= Split-Path "$source1" -leaf -ErrorAction SilentlyContinue
                            $test = Test-Path $input\$file

                            if ($test) 
                                    {
                                            Write-Output "$(get-date) : $input\$file is found" | Out-File $outfile2 -Append
                                            Write-Output "$(get-date) : Copy-Item -Path $input\$file -Destination $dest" | Out-File $outfile2 -Append
                                            Copy-Item -Path "$input\$file" -Destination "$dest" -Force
                                    } 
                            else 
                                    {
                                            Write-Output "$(get-date) : $input\$source is not found" | Out-File $outfile2 -Append
                                            $new_path = Get-ChildItem -Path $input\$file -Recurse
                                            $new_path = $new_path.DirectoryName
                                            $Val_path= Test-Path $new_path\$file
        
                                            if($Val_path)
                                                    {
                                                            Write-Output "$(get-date) : Copy-Item -Path "$new_path\$file" -Destination "$dest"" | Out-File $outfile2 -Append
                                                            Copy-Item -Path "$new_path\$file" -Destination "$dest" -Force
                                                    } 
                                            else 
                                                    {
                                                            Write-Output "$(get-date) : File not found in $input folder" | Out-File $outfile2 -Append
                                                            Write-Output "$env:computername,Failed,MSI/MSP file is not available in SQL binary path. Fix the issue and retry,NA,NA" | out-file y:\report\summaryreport.csv -Append
                                                            Exit
                                                    }
                                    }
            }
    } 

    del $arg_log\parsed*.txt 

#Identification of system type (standalone or Cluster)
    $s = Get-WmiObject -Class Win32_SystemServices -ComputerName $server_name 
    if ($s | select PartComponent | where {$_ -like "*ClusSvc*"}) 
            { 
                        Write-Output "$(get-date) : $server_name is Clustered" | Out-File $outfile2 -Append 
            }
    else 
            { 
                        Write-Output "$(get-date) : $server_name is Not clustered" | Out-File $outfile2 -Append 
            }

#db health check with service checks
    Write-Output "$(get-date) : Current automatic services status:" | Out-File $outfile2 -Append 

#if (Test-Path \\$ComputerName\c$){ 
    $serviceinfo = Get-WmiObject -Class win32_service  -ComputerName $env:computername -Filter "startmode='Auto'" -ErrorAction SilentlyContinue | Select-Object PSComputerName,Name,StartMode,State,StartName
    if ($serviceinfo) 
            {
                $serviceinfo
                $serviceinfo | Format-Table -property PSComputerName,Name,StartMode,State,StartName | Out-File $outfile2 -Append
            } 
    Else 
            {
                     $serviceinfo =new-object psobject 
                     $serviceinfo |Add-Member noteproperty "PSComputerName" $env:computername
                     $serviceinfo |Add-Member noteproperty "Name" $sname 
                     $serviceinfo |Add-Member noteproperty "StartMode" "Na" 
                     $serviceinfo |Add-Member noteproperty "State" "Na"
                     $serviceinfo |Add-Member noteproperty "StartName" "Na" 
  
 #display the results 
                     $serviceinfo | Select-Object "PSComputerName","Name","StartMode","State","StartName"
                     $serviceinfo | Format-Table -property PSComputerName,Name,StartMode,State,StartName | Out-File $outfile2 -Append
            }

    (Get-Service | Select-Object -Property Name,Status,StartType | Where-Object {$_.Status -eq "Stopped" -and $_.StartType -eq "Automatic"}).Name > $Parent_Path\logs\services_before.txt

#Check Disk Space
    $New = Get-CimInstance -Class Win32_LogicalDisk | Select-Object @{Name="Size(GB)";Expression={$_.size/1gb}}, @{Name="Free Space(GB)";Expression={$_.freespace/1gb}}, @{Name="Free";Expression={"{0,6:P0}" -f(($_.freespace/$_.size))}}, DeviceID, DriveType | Where-Object DriveType -EQ '3'
    $var= $New.Free 
    $me = $var -Replace '%',''
    $messyString = "$me"
    [int]$myInt = $messyString -replace '\D', ''
#$myInt

    if ($myInt -le 15)
            {
                    Write-Output "$(get-date) : Current Freespace is $var which is lesser than 15%" | Out-File $outfile2 -Append
#Report in summary report 
                    Write-Output "$env:computername,Failed,Patch is not installed due to system drive is less than 15%,NA,NA" | out-file y:\report\summaryreport.csv -Append
                    del $arg_log\*.txt
                    exit
            }
    else
            {
                    Write-Output "$(get-date) : Current Freespace is $var which is greater than 15%" | Out-File $outfile2 -Append
            }


#Validation of Pending Reboot
    function Test-PendingReboot 
            {
                    if (Get-ChildItem "HKLM:\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending" -EA Ignore) { return $true }
                    if (Get-Item "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired" -EA Ignore) { return $true }
                    if (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" -Name PendingFileRenameOperations -EA Ignore) { return $true }
                    
                        try 
                                {
                                        $util = [wmiclass]"\\.\root\ccm\clientsdk:CCM_ClientUtilities"
                                        $status = $util.DetermineIfRebootPending()
                    
                                        if (($status -ne $null) -and $status.RebootPending) 
                                                {
                                                        return $true
                                                }
                                }
                        catch { }
            
                    return $false
            }

    $arg_PendingReboot = Test-PendingReboot

    if($arg_PendingReboot -eq "True")
            {
                    Write-Output "$(get-date) : Pending reboot is True" |Out-File $outfile2 -Append

#System reboot
                            if($param2.ToLower() -eq "y")
                                    {
                                                cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "LocaleSettings" /t REG_EXPAND_SZ /d "powershell.exe $Parent_Path\Before_patch_v2.ps1 $Parent_Path" /f
                                                cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "DefaultUserName" /t REG_SZ /d "$param9" /f
                                                cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "DefaultPassword" /t REG_SZ /d "$DECODED" /f
                                                cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "AutoAdminLogon" /t REG_SZ /d "1" /f

                                                Write-Output "$arg_patchexe,$param5,$param2,$param8,$param1,$param9,$param10,$param4" > $arg_log\input.txt
                                                Write-Output "$(get-date) : Reboot selected, hence rebooting" | Out-File $outfile2 -Append
                                                cmd /c shutdown -r -t 0
                                                Exit
                                    }
                            else
                                    {
                                                Write-Output "$(get-date) : reboot not selected, hence server was not rebooted" | Out-File $outfile2 -Append
                                                Write-Output "$env:computername,Failed,Patch is not installed due to reboot pending,NA,NA" | out-file y:\report\summaryreport.csv -Append
                                                exit
                                    }
           }
    else
            {
                    Write-Output "$(get-date) : Pending reboot is False" |Out-File $outfile2 -Append
            }
 
#installation of patch
    $arg_patchexe

    if ($param5.ToLower() -eq "all")
            {
                    $job = Start-Job -ScriptBlock {cmd /c $using:arg_patchexe /q /IAcceptSQLServerLicenseTerms /Action=Patch /AllInstances}
                    $job
                    Wait-Job $job
            } 
    else 
            {
                foreach ($Instance in $arg_instance)
                            {
                                    $job = Start-Job -ScriptBlock {cmd /c $using:arg_patchexe /q /IAcceptSQLServerLicenseTerms /Action=Patch /InstanceName=$using:Instance}
                                    Wait-Job $job
                                    $arg_instance = $Instance
                            } # end of foreach loop
            } # end of instance($param5) check

    foreach ($instance in $arg_instance)
            {
#validation of patch installation

                        if ($arg_instance -eq "MSSQLSERVER")
                            { 
                                    $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name" -Query "SELECT @@VERSION"
                            }
                        Else 
                            {
                                    $arg_details= Invoke-Sqlcmd -ServerInstance "$server_name\$instance" -Query "SELECT @@VERSION"
                            }

                    $arg_details.Column1 -match 'KB\d*'
                    $New_KBnumber = $Matches[0]
#Write-Output "$arg_KB" | Out-File $arg_log\KBnumber1.txt
            }

    $KBnumber = gc $arg_log\KBnumber.txt
#$New_KBnumber = gc $arg_log\KBnumber1.txt
    $arg_summary = gc "$param4\summary.txt"
    $arg_summary -replace (",","") | Out-File $arg_log\summary.txt
    $arg_summary = gc "$arg_log\summary.txt"

    if($KBnumber -eq $New_KBnumber)
            {
                    $arg_patchexe -match '(KB\d+)'
                    $patchKB = $Matches[0]

                    if ($patchKB -eq $New_KBnumber) 
                            {
                                    Write-Output "$(get-date) : This patch is already installed" |Out-File $outfile2 -Append
                                    Write-Output "$env:computername,Successfull,Patch is already installed and server is not rebooted,NA,'$arg_summary'" | out-file y:\report\summaryreport.csv -Append
                                    del $arg_log\*.txt
                                    exit
                            } 
                    else 
                            {
                                    $arg_patchstatus = "False"
                                    Write-Output "$env:computername,Failed,Patch install failed and server is not rebooted,NA,'$arg_summary'" | out-file y:\report\summaryreport.csv -Append
                                    del $arg_log\*.txt
                                    exit
                            }

#Report in summary report
            }
    else
            {
                    Write-Output "$(get-date) : Patches are successfully installed" | Out-File $outfile2 -Append
#System reboot
                    if($param2.ToLower() -eq "y")
                    {
                            cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce" /v "LocaleSettings" /t REG_EXPAND_SZ /d "powershell.exe $Parent_Path\After_patch_v2.ps1 $Parent_Path" /f
                            cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "DefaultUserName" /t REG_SZ /d "$param9" /f
                            cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "DefaultPassword" /t REG_SZ /d "$DECODED" /f
                            cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "AutoAdminLogon" /t REG_SZ /d "1" /f
                            Write-Output "$(get-date) : Reboot selected, hence rebooting" | Out-File $outfile2 -Append
                            cmd /c shutdown -r -t 0
                    }
                    else
                    {
                            Write-Output "$(get-date) : reboot not selected, hence server was not rebooted" | Out-File $outfile2 -Append
                            Write-Output "$env:computername,Successfull,Patch installed and server is not rebooted as reboot is not selected,NA,'$arg_summary'" | out-file y:\report\summaryreport.csv -Append
                            del $arg_log\*.txt
                    }
                }

    net use y: /delete
    Exit