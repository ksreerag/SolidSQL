﻿cls
Write-Host "              ************************************************************"
Write-Host "              ************************************************************"
Write-Host "              ** Script for SQL patching remotely with Multiple servers **"
Write-Host "              ** Tower : Database Architecture & Delivery	            **"
Write-Host "              ************************************************************"
Write-Host "              ************************************************************"
#$Parent_Path = $args[0]
Start-Sleep -Seconds 180

function Test-Admin {
$currentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent())
$currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}
if ((Test-Admin) -eq $false) {
if ($elevated)
{
Write-Host "tried to elevate, did not work, aborting"
} else {
Start-Process powershell.exe -Verb RunAs -ArgumentList ('-noprofile -noexit -file "{0}" -elevated' -f ($myinvocation.MyCommand.Definition))
}
exit
}
$Parent_Path = $args[0]
Split-Path -Path $Parent_Path -Qualifier
cd $Parent_Path

$arg_log = "$Parent_Path\logs"
$arg_input = gc $Parent_Path\Master_input.log
$arg_input = $arg_input.Split(",")

#To define parameters
$param1=$arg_input[0]   #Source of master script location
$param9=$arg_input[7] # UserName
$param10=$arg_input[8] # Password
$param4=$arg_input[9] #bootstraplog path

#Decode
$MYTEXT = "$param10"
$DECODED = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($MYTEXT))
net use y: $param1 /user:$param9 $DECODED

$outfile2 = "$Parent_Path\logs\Patch_$(Get-Date -UFormat "%m-%Y").log"
Write-output "$(get-date) : Server successfully rebooted" | Out-File $outfile2 -Append
#$arg_services = (Get-Service | Select-Object -Property Name,Status,StartType | Where-Object {$_.Status -eq "Stopped" -and $_.StartType -eq "Automatic"}).Name
(Get-Service | Select-Object -Property Name,Status,StartType | Where-Object {$_.Status -eq "Stopped" -and $_.StartType -eq "Automatic"}).Name > $Parent_Path\logs\services_after.txt
$arg_services = (Compare-object (get-content "$Parent_Path\logs\services_before.txt") (get-content "$Parent_Path\logs\services_after.txt") | where {$_.sideIndicator -eq "=>"}).Inputobject
cmd /c reg delete "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "DefaultPassword" /f
cmd /c reg add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v "AutoAdminLogon" /t REG_SZ /d "0" /f
$arg_summary = gc "$param4\summary.txt"
$arg_summary -replace (",","") | Out-File $arg_log\summary.txt
$arg_summary = gc "$arg_log\summary.txt"
Write-Output "$env:computername,Successfull,Patch installed and server is rebooted,$arg_services,'$arg_summary'" | out-file y:\report\SummaryReport.csv -Append
#del $arg_log\*.txt
net use y: /delete
logoff