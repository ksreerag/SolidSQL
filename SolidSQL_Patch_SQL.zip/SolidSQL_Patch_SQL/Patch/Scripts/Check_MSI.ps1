﻿# "              ************************************************************"
# "              ************************************************************"
# "              ** Script for SQL patching remotely with Multiple servers **"
# "              ** Tower : Database Architecture & Delivery               **" 
# "              ************************************************************"
# "              ************************************************************"
$Parent_Path = $args[0]
$arg_log = "$Parent_Path\logs"
$arg_log1= Test-Path $arg_log
if($arg_log1){
# Folder exist   
} else{
    New-Item -Path "$Parent_Path" -Name "logs" -ItemType "directory" -Force | Out-Null
}

$arg_input = gc $Parent_Path\Master_input.log
$arg_input = $arg_input.Split(",")

#To define parameters
$param1=$arg_input[0]   #Source of master script location
$param9=$arg_input[7] # UserName
$param10=$arg_input[8] # Password
$param2=$arg_input[6] # SQL_Binary_Path

#Decode
$MYTEXT = "$param10"
$DECODED = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($MYTEXT))
net use y: $param1 /user:$param9 $DECODED | Out-Null

cscript $Parent_Path\FindSQLInstalls.vbs $arg_log\output.txt | Out-Null
$input = "$param2"   #source files folder
$text = gc $arg_log\output.txt     
$text | Select-String -Pattern 'Action needed, recreate or re-establish path.*' -Context 0,10 | out-file $arg_log\parsed.txt
$Val_file = [String]::IsNullOrWhiteSpace((gc $arg_log\parsed.txt))
cls
if($Val_file){
cls
Write-Host "No MSI/MSP files are missing"
} else { 
$text1 = gc $arg_log\parsed.txt #-Raw
$text1 | Select-String -Pattern '"\w+.*' -Context 0,1 | out-file $arg_log\parsed1.txt
$hash = @{} 
(gc $arg_log\parsed1.txt) | ? {$_.trim() -ne "" } | set-content $arg_log\parsed1.txt
gc $arg_log\parsed1.txt | %{if($hash.$_ -eq $null) { $_ }; $hash.$_ = 1} | out-file $arg_log\parsed2.txt
Set-Content -Path "$arg_log\parsed3.txt" -Value (get-content -Path "$arg_log\parsed2.txt" | Select-String -Pattern '> ' -NotMatch)
Try {
$text3 = (gc $arg_log\parsed3.txt -Raw -ErrorAction Continue).Trim()
$text3.Replace("`" `r`n"," ") | out-file $arg_log\parsed4.txt
}
Catch
{
#Write-Host "File is empty"
$text3 = (gc $arg_log\parsed2.txt -Raw -ErrorAction Continue).Trim()
$text3.Replace(">        Copy ","") | out-file $arg_log\parsed4.txt
}
$text2 = (gc $arg_log\parsed4.txt).Trim()
foreach ($source in $text2) {
$source = $source.Replace("`"","")
$source1 = $source -split '   '
if ($source1.Count -eq "1"){
    $source = $source -split ' '
} else {
    $source = $source -split '   '
}
$source1 = $source[0]
$dest = $source[1]
$file= Split-Path "$source1" -leaf -ErrorAction SilentlyContinue
$test = Test-Path $input\$file
if ($test) {
#Write-Output "$(get-date) : $input\$file is found" | Out-File $outfile2 -Append
#Write-Output "$(get-date) : Copy-Item -Path $input\$file -Destination $dest" | Out-File $outfile2 -Append
Copy-Item -Path "$input\$file" -Destination "$dest" -Force
} else {
cls
Write-Host "$input\$source is not found"
$new_path = Get-ChildItem -Path $input\$file -Recurse
$new_path = $new_path.DirectoryName
$Val_path= Test-Path $new_path\$file
if($Val_path){
#Write-Output "$(get-date) : Copy-Item -Path "$new_path\$file" -Destination "$dest"" | Out-File $outfile2 -Append
Copy-Item -Path "$new_path\$file" -Destination "$dest" -Force
} else {
#Write-Output "$(get-date) : File not found in $input folder" | Out-File $outfile2 -Append
cls
Write-Host "MSI/MSP file is not available in SQL binary path. Fix the issue and retry"
}
}
}
} 
del $arg_log\parsed*.txt