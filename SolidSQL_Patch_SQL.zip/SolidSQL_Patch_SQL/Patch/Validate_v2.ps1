﻿cls
Write-Host "              ***********************************************************************"
Write-Host "              ***********************************************************************"
Write-Host "              ** Script for SQL patching Validation remotely with Multiple servers                         **"
Write-Host "              ** version : 1.0                                                                                                  **"
Write-Host "              ** Tower : Database Architecture & Delivery**"
Write-Host "              ***********************************************************************"
Write-Host "              ***********************************************************************"

    $Parent_Path = (Get-Location).Path

#collecting source path
    $a = Split-Path -Path $Parent_Path -Qualifier
    $a1= $a -replace ":","$"
    
    $b = $Parent_Path -replace "$a",""
    $arg_sourcepath = "\\$env:computername\$a1$b"

#Collecting Windows credentials
    $Credentials = Get-Credential

    New-Item $Parent_Path\Report\Validation_Report.csv -ItemType File -force

    Write-Output "Server Name,Winrm Status,Copy Patch,MSI Details" > $Parent_Path\Report\Validation_Report.csv

    $arg_input = Import-Csv $Parent_Path\Input\Input_Sql.csv

    foreach ($input in $arg_input) 
        {
                
                if ($input -eq "") 
                    {            
                            #Write-host "Line is empty"               
                    } 
                
                #Else start
                else 
                    {
                            $arg_servername = $input.servername    #Servername
                            $arg_instance = $input.instancename      #SQL Server instance name
                            $arg_patch = $input.patchexe      #patch exe file name
                            #$arg_install = $input.InstallDir
                            $arg_bakdir = $input.bakdir     #backup directory
                            $arg_bootlog = $input.bootstraplogdir      #bootstraplog directory for installation summary
                            $arg_reboot = $input.Allowreboot            #parameter decide target server can reboot 
                            $arg_Remotepatch = $input.Remote_patchpath        #target path to keep the patch file
                            $arg_SQL_Binary_Path = $input.SQL_Binary_Path     #SQL Server binary path
                            $arg_scriptpath = $input.Remote_Script_Folder       #target script folder to keep the scripts while patching
                            $arg_SSMSPatch = $input.SSMS_Patch    #patch SSMS 
                            $arg_SSMSPatchName = $input.SSMS_Patch_Name   #SSMS patch  file name
                            $arg_SSRSPatch = $input.SSRS_Patch   #patch SSRS
                            $arg_SSRSPatchName = $input.SSRS_Patch_Name    #SSRS patch file name

                            $a = Split-Path -Path $arg_Remotepatch -Qualifier
                            $a1= $a -replace ":","$"
        
                            $b = $arg_Remotepatch -replace "$a",""
                            $arg_tarpath = "\\$arg_servername\$a1$b"

                            $Username = $Credentials.username
                            $Password = $Credentials.GetNetworkCredential().password

                            $MYTEXT = "$Password"
                            $ENCODED = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($MYTEXT))

                            #Write-Host "$arg_servername - $arg_instance - $arg_patch - $arg_install - $arg_bakdir - $arg_bootlog - $arg_reboot"
                                     Try 
                                            {
                                                     $arg_session = New-PSSession -ComputerName $arg_servername -Credential $Credentials -ErrorAction Stop
                                                      $Winrm_connection = "Success"
                                            }
                                    Catch 
                                            {
                                                    $ErrorMessage = $_.Exception.Message
                                                    $Winrm_connection = "Failed"
                                            }

                                            if ($Winrm_connection -eq "Success") 
                                            {
                                                                    Invoke-Command -Session $arg_session {$arg_Testpath = Test-Path -Path "$using:arg_scriptpath"}
                                                                    $arg_path = Invoke-Command -Session $arg_session {$arg_Testpath
                                            }
                        
#start of folder check 
                                           if($arg_path)
                                                    {
                                                          #Folder is available
                                                    }
                                           else 
                                                    {
                                                        #Folder is not available
                                                        Invoke-Command -Session $arg_session {New-Item -Path "$using:arg_scriptpath" -ItemType "directory" -Force}
                                                    }
#end of folder check 

#copying patches to remote server
                                            $arg_Targetpath = Invoke-Command -Session $arg_session {Test-path $using:arg_Remotepatch}
                            
                                            if($arg_Targetpath)
                                                         {                        }
                                            else
                                                         {
                                                                         Invoke-Command -Session $arg_session {New-Item -Path "$using:arg_Remotepatch" -ItemType "directory" -Force}
                                                                         #Write-Host "Successfully created the target patch folder"
                                                         }
                    
                                            $arg_pachpath = Invoke-Command -Session $arg_session {Test-Path -Path "$using:arg_Remotepatch\$using:arg_patch"}
                                            #$arg_path1 = Invoke-Command -Session $arg_session {$arg_pachpath}

                                            if($arg_pachpath)
                                                        {
                                                                        Write-host "Patch is available on server $arg_servername"
                                                                        $PatchCopy = "Success"
                                                                        #Write-Output "$arg_servername,$Winrm_connection,Success" | Out-File $Parent_Path\Report\Validation_Report.csv -Append
                                                        } 
                           
                                            #Else start
                                            else 
                                                        {
                           
                                                                            #Patch is not available
                                                                            Try
                                                                                            {
                                                                                                                #Copy-Item -Path "$Parent_Path\Patches\$arg_patch" -ToSession $arg_session -Destination "$arg_Remotepatch" -ErrorAction Stop
                                                                                                                net use y: $arg_tarpath /user:$Username $Password
                                                                                                                copy "$Parent_Path\Patches\$arg_patch" y:
                                                                                                                $PatchCopy = "Success"
                                                                                            } 
                                                                            Catch
                                                                                            {
                                                                                                                $PatchCopy = "Failed"
                                                                                                                #Write-Output "$arg_servername,$Winrm_connection,$PatchCopy" | Out-File $Parent_Path\Report\Validation_Report.csv -Append
                                                                                            }

                                                                            if ($PatchCopy -eq "Success") 
                                                                                            {
                                                                                                                Write-Host "Successfully copied the patches on server $arg_servername"
                                                                                            } 
                                                                            else 
                                                                                            {
                                                                                                                Write-Host "Failed to copy Patches on server $arg_servername"
                                                                                            }
                     
                                                            net use y: /delete
                                                        }
                                                #Else end

                                    Copy-Item -path "$Parent_Path\scripts\*.*" -Destination "$arg_scriptpath" -ToSession $arg_session -Force

                                    Invoke-Command -Session $arg_session{Write-Output "$using:arg_sourcepath,$using:arg_reboot,$using:arg_patch,$using:arg_instance,$using:arg_bakdir,$using:arg_Remotepatch,$using:arg_SQL_Binary_Path,$using:Username,$using:ENCODED,$using:arg_bootlog,$using:arg_SSMSPatch,$using:arg_SSMSPatchName,$using:arg_SSRSPatch,$using:arg_SSRSPatchName" > $using:arg_scriptpath\Master_input.log} 
                    
                                    Invoke-Command -Session $arg_session{$arg_result = powershell -NoProfile -File "$using:arg_scriptpath\Check_MSI.ps1" $using:arg_scriptpath}
                                    
                                    $arg_result1 = Invoke-Command -Session $arg_session {$arg_result}
                                    Write-host $arg_result1

                                    Write-Output "$arg_servername,$Winrm_connection,$PatchCopy,$arg_result1" | Out-File $Parent_Path\Report\Validation_Report.csv -Append

                } 
                
                else 
                        {
                                    Write-Output "$arg_servername,$Winrm_connection,Failed,NA" | Out-File $Parent_Path\Report\Validation_Report.csv -Append
                        } #end of winrm validation

            } # Line is not empty
        
        } # end of foreach

    $reportPath = "$Parent_Path\Report\"
    Del $reportPath\Validation_Report.html
    
# Report name 
    $reportName = "Validation_Report.html"; 
 
#Path and Report name together 
    $PatchReport = $reportPath + $reportName 
 
#Set colors for table cell backgrounds 
    $redColor = "#FA0033"

#$orangeColor = "#FA6600"
    $greenColor = "#00FF00"
 
# Create and write HTML Header of report 
    $titleDate = (Get-Date).ToString('MMMM-yyy') 
    $header = " 
                    <html> 
                        <head> 
                               <meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'> 
                                            <title>SQL Patch Report</title> 
                                                        <STYLE TYPE='text/css'> 
                                                                                        <!-- 
                                                                                                 td
                                                                                                        { 
                                                                                                                       font-family: Calibri; 
                                                                                                                       font-size: 14px; 
                                                                                                                       border-top: 1px solid #999999; 
                                                                                                                       border-right: 1px solid #999999; 
                                                                                                                       border-bottom: 1px solid #999999; 
                                                                                                                       border-left: 1px solid #999999; 
                                                                                                                       padding-top: 0px; 
                                                                                                                       padding-right: 0px; 
                                                                                                                       padding-bottom: 0px; 
                                                                                                                       padding-left: 0px; 
                                                                                                        } 
                                                                                                
                                                                                                body 
                                                                                                        { 
                                                                                                                       margin-left: 25px; 
                                                                                                                       margin-top: 5px; 
                                                                                                                       margin-right: 0px; 
                                                                                                                       margin-bottom: 10px; 
                                                                                                            table 
                                                                                                                        { 
                                                                                                                                border: thin solid #000000; 
                                                                                                                        } 
                                                                                           --> 
                                                    </style> 
                    </head> 
                    <body> 
                                <table width='60%'> 
                                                               <tr> 
                                                                        <td colspan='7' height='30' align='center'> 
                                                                                                                  <font face='calibri' color='#003399' size='6'>
                                                                                                                                           <strong>
                                                                                                                                                            SQL Patch Validation Report
                                                                                                                                            </strong>
                                                                                                                 </font> 
                                                                        </td> 
                                                               </tr> 
                                </table> 
" 
    Add-Content $PatchReport $header 
 
# Create and write Table header for report 
    $tableHeader = " 
                                <table width='60%'><tbody> 
                                                                        <tr bgcolor=#7030A0> 
                                                                                                         <td width='15%' height='30' size='4' align='center'><font face='calibri' color='White'>
                                                                                                                            Server Name
                                                                                                         </td> 
                                                                                                         <td width='15%'  height='30' size='4' align='center'><font face='calibri' color='White'>
                                                                                                                            Winrm Status
                                                                                                         </td> 
                                                                                                         <td width='15%' height='30' size='4' align='center'><font face='calibri' color='White'>
                                                                                                                            Copy Patch
                                                                                                         </td> 
                                                                                                         <td width='15%' height='30' size='4' align='center'><font face='calibri' color='White'>
                                                                                                                            MSI Details
                                                                                                         </td> 
                                                                        </tr> 
                            " 

    Add-Content $PatchReport $tableHeader 
    # $File_Path = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    # $PrevReoprt = $((Get-Date)).ToString('MM-yyyy')

    $csv = Import-Csv "$reportPath\Validation_Report.csv" 
    foreach ($property in $csv)
        {
                        $ServerName = $property."Server Name";
                        $WinrmStatus = $property."Winrm Status";
                        $CopyPatch = $property."Copy Patch";
                        $MSIDetails = $property."MSI Details";
                      #  $color1 = $redColor;
                      
                                if($property."Winrm Status" -eq "Success")
                                        {
                                                    $color = $greenColor;
                                        }
                                        else
                                        {
                                                    $color = $redColor;
                                        }
                        
                                if($property."Copy Patch" -eq "Success")
                                        {
                                                    $color1 = $greenColor;
                                        }
                                else
                                        {
                                                    $color1 = $redColor;
                                        }
                        
                                if($property."MSI Details" -eq "No MSI/MSP files are missing")
                                        {
                                                $color2 = $greenColor;
                                         }
                               else
                                         {
                                               $color2 = $redColor;
                                         }
         
        #Create table data rows  
                $dataRow = " 
              <tr> 
                          <td width='15%'>$ServerName</td> 
                          <td width='15%' bgcolor=`'$color`' align='left'>$WinrmStatus</td> 
                          <td width='15%' bgcolor=`'$color1`' align='left'>$CopyPatch</td> 
                          <td width='15%' bgcolor=`'$color2`' align='left'>$MSIDetails</td> 
              </tr> 
                                 " 
 
            Add-Content $PatchReport $dataRow;
      }

# Create table at end of report showing legend of colors for the critical and warning 
        Add-Content $PatchReport "</body></html>" 