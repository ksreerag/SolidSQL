 CLS
Write-Host "              *******************************************************"
Write-Host "              *******************************************************"
Write-Host "              ** Generic utility to execute any SQL script against the database **"
Write-Host "              **                                                                                         **"
Write-Host "              ** Developed By: sreerag.kunnapath@gmail.com                          **"
Write-Host "              ** version : 1.0                                                                       **"
Write-Host "              ** Date : 19/08/2023                                                               **"
Write-Host "              ** Tower : Database Architecture & Delivery    **" 
Write-Host "              ********************************************************"
Write-Host "              ********************************************************"

#Variable declaration
    $Scriptpath  = $args[0]    #Path
    $Server =  $args[1]         #SQL Server instance
    $database = $args[2]      #Database to be executed
    $user= $args[3]             #Credentials to connect database instance
    $pwd= $args[4]             #Credentials to connect database instance
    $Includesubfolders=$args[5]   #Path where script exists

   Write-Output "=========================================================================" |Out-File $Scriptpath\$Server"_Hardening_output.log" -Append

    Function IsDBInstalled([string]$Server, [string]$database)
        {
                Try 
                    {
                                 Invoke-Sqlcmd -ServerInstance $Server -Username  $user -Password  $pwd -Database $database -Query "select 1 from sys.databases where name='$database'" -OutputSqlErrors $true 
                                 Write-Output  (Get-Date).tostring('MM-dd-yyyy hh:mm') "Server :$Server Database :$database User :$user" |Out-File $Scriptpath\$Server"_Hardening_output.log" -Append
                                 write-host (Get-Date).tostring('MM-dd-yyyy hh:mm') "Connected to SQL Server $Server" -BackgroundColor blue -ForegroundColor black
                    }
                Catch 
                    {
                                Write-Output  (Get-Date).tostring('MM-dd-yyyy hh:mm')"Failed to connect to $Server" |Out-File $Scriptpath\$Server"_Hardening_output.log" -Append
                                Write-Output "Error : $error "|Out-File $Scriptpath\$Server"_Hardening_output.log" -Append
                                #Write-Host ($error) -BackgroundColor darkred 
                                Write-Error "Failed to connect to $Server" -ErrorAction Stop
                    }

        }#End of Function
 
    IsDBInstalled $Server $database

    if($Includesubfolders -eq 1) 
            {
                $subscripts = Get-ChildItem $Scriptpath -recurse | Where-Object {$_.Extension -eq ".sql"}

                foreach ($s in $subscripts)
                    {   
                            Write-Host "Running Script : " $s.Name -BackgroundColor green -ForegroundColor darkRed
                            $tables=Invoke-Sqlcmd -ServerInstance $Server -Username  $user -Password  $pwd -Database  $database -InputFile $s.FullName -ErrorAction 'Stop' -Verbose
                         
                            #-querytimeout ([int]::MaxValue)   
                        
                            write-host ($tables | Format-List | Out-String) 

                    } #End of Foreach
            } 
   else 
            {
                $scripts = Get-ChildItem $Scriptpath | Where-Object {$_.Extension -eq ".sql"}
                
                foreach ($s in $scripts)
                    {   
                    
                            Write-Host "Running Script : " $s.Name -BackgroundColor green -ForegroundColor darkRed
                            $tables=Invoke-Sqlcmd -ServerInstance $Server -Username  $user -Password  $pwd -Database  $database -InputFile $s.FullName -ErrorAction 'Stop' -Verbose
                             
                            #-querytimeout ([int]::MaxValue)
        
                            #write-host ($tables | Format-List | Out-String) 

                    }#End of Foreach
            }
 
    Write-Output ($tables | Format-List | Out-String) |Out-File $Scriptpath\$Server"_Hardening_output.log" -Append